<?php

/**
 * Form Tools Theme File
 * ---------------------
 */

$theme_name = "Classic Grey";
$theme_author = "Encore Web Studios";
$theme_author_email = "formtools@encorewebstudios.com";
$theme_link = "http://themes.formtools.org/classicgrey/";
$theme_description = "A remodelling of the old grey-styled Form Tools 1.x theme.";
$theme_version = "1.1.3";